import pandas as pd
import pickle
from datetime import datetime
import numpy as np


input_df = pd.read_csv('..\\input\\claim_data.csv')

dec_dis = np.array(input_df[['Declared ' + s + str(x) for x in range(5) for s in 'IJK']])
cov_dis = np.array(input_df[['Cov Dis ' + str(i) for i in range(60)]])
reimb_dis = np.array(input_df[['Disease ' + str(i) for i in range(12)]])

dec = [s + str(x) for x in range(5) for s in 'IJK']
dis_codes = np.zeros((input_df.shape[0], 12))

for i in range(input_df.shape[0]):
    for j in range(12):
        if reimb_dis[i][j] == '0':
            continue
        elif reimb_dis[i][j] in cov_dis[i]:
            dis_codes[i][j] = 1
        elif reimb_dis[i][j] not in cov_dis[i]:
            dis_codes[i][j] = 2
        if reimb_dis[i][j] in dec and dec_dis[i][dec.index(reimb_dis[i][j])] == 0:
        	dis_codes[i][j] = 3

dis_codes = dis_codes.astype(int)

dis_codes_df = pd.DataFrame(dis_codes, columns=['Dis Cls ' + str(i) for i in range(12)])

model = pickle.load(open('gbc.pkl', 'rb'))

ID = input_df['Insurance ID']

df = pd.concat([input_df, dis_codes_df], axis=1)

df['days'] = [(datetime.strptime(df.iloc[i]['Reimbursement Date'], '%d-%m-%Y') - datetime.strptime(df.iloc[i]['Purchase Date'], '%d-%m-%Y')).days for i in range(df.shape[0])]
df['Age'] = [(datetime.strptime(df.iloc[i]['Reimbursement Date'], '%d-%m-%Y') - datetime.strptime(df.iloc[i]['DOB'], '%d-%m-%Y')).days for i in range(df.shape[0])]
df['Care Duration'] = [(datetime.strptime(df.iloc[i]['To Date'], '%d-%m-%Y') - datetime.strptime(df.iloc[i]['From Date'], '%d-%m-%Y')).days for i in range(df.shape[0])]
df = df[['Tenure', 'Available Amount', 'Gender', 'Occupation', 'Age',
       'Total Expense', 'Care Duration', 'Dis Cls 0', 'Dis Cls 1', 'Dis Cls 2',
       'Dis Cls 3', 'Dis Cls 4', 'Dis Cls 5', 'Dis Cls 6', 'Dis Cls 7',
       'Dis Cls 8', 'Dis Cls 9', 'Dis Cls 10', 'Dis Cls 11', 'days']]
X = df.astype(int)
predictions = model.predict(X)

if predictions[0] == 2:
	try:
		model_1 = pickle.load(open('gbc_1.pkl', 'rb'))
		predictions_1 = model_1.predict(X)
		if predictions_1[0] == 1:
			predictions = 3
	except:
		pass

predictions_df = pd.DataFrame(predictions, columns=['Result'])
predictions_df['Insurance ID'] = ID
predictions_df = predictions_df.reindex(columns=['Insurance ID', 'Result'])
predictions_df.to_csv('..\\output\\Results.csv', index=False)
